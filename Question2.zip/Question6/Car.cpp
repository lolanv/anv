#include "Car.h"

std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_m_car_reg_num: " << rhs._m_car_reg_num
       << " _m_price: " << rhs._m_price
       << " _m_car_engine: " << rhs._m_car_engine;
    return os;
}

Car::Car(std::string reg_num, float price, EngineRef engine_ref)
: _m_car_reg_num(reg_num), _m_price (price),_m_car_engine(engine_ref)
{
}