#ifndef CAR_H
#define CAR_H

#include <iostream>
#include <functional>
#include "Engine.h"

class Car;

using EngineRef = std::reference_wrapper<Engine>;

class Car
{
private:
    /* data */
    std::string _m_car_reg_num;
    float _m_price;
    EngineRef _m_car_engine;

public:
    Car() =default;
    Car(const Car&)=default;
    Car(Car&&)=default;
    Car& operator=(const Car&)=default;
    Car& operator=(Car&&)=default;
    ~Car()=default;

    Car(std::string reg_num, float price, EngineRef engine_ref);


   
    std::string mCarRegNum() const { return _m_car_reg_num; }
    void setMCarRegNum(const std::string &m_car_reg_num) { _m_car_reg_num = m_car_reg_num; }

    float mPrice() const { return _m_price; }
    void setMPrice(float m_price) { _m_price = m_price; }

    EngineRef mCarEngine() const { return _m_car_engine; }
    void setMCarEngine(const EngineRef &m_car_engine) { _m_car_engine = m_car_engine; }

   

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);

    


};

#endif // CAR_H