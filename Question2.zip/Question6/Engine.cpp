#include "Engine.h"

std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_m_engine_number: " << rhs._m_engine_number
       << " _m_engine_torque: " << rhs._m_engine_torque
       << " _m_horsepower: " << rhs._m_horsepower;

       switch (rhs._m_engine_type)
       {
       case EngineType::CRDI :
        os<<"EngineType: CRDI\n";
        break;

       case EngineType::NPFI :
        os<<"EngineType: NPFI\n";
        break;

       case EngineType::TURBOCHARGED:
        os<<"EngineType: TURBOCHARGED\n";
        break;

       }
    
    return os;
}

Engine::Engine(std::string engine_num, int torque, int horsepower, EngineType _engine_Type)
: _m_engine_number(engine_num),_m_engine_torque(torque),_m_horsepower(horsepower),_m_engine_type(_engine_Type)
{
}
