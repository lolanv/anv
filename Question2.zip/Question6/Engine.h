#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "EngineType.h"

class Engine
{
private:
    std::string _m_engine_number;
    int _m_engine_torque;
    int _m_horsepower;
    EngineType _m_engine_type;
public:
    Engine()=delete;
    Engine(const Engine&)=delete;
    Engine(Engine&&)=default;
    Engine& operator=(const Engine&)=delete;
    Engine& operator=(Engine&&)=delete;
    ~Engine()=default;

    Engine(std::string engine_num, int torque, int horsepower, EngineType _engine_Type);
    

    //getters and setters functions
    std::string mEngineNumber() const { return _m_engine_number; }
    void setMEngineNumber(const std::string &m_engine_number) { _m_engine_number = m_engine_number; }

    int mEngineTorque() const { return _m_engine_torque; }
    void setMEngineTorque(int m_engine_torque) { _m_engine_torque = m_engine_torque; }

    int mHorsepower() const { return _m_horsepower; }
    void setMHorsepower(int m_horsepower) { _m_horsepower = m_horsepower; }

    EngineType mEngineType() const { return _m_engine_type; }
    void setMEngineType(const EngineType &m_engine_type) { _m_engine_type = m_engine_type; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);

    
};

#endif