#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType{
    CRDI,
    NPFI,
    TURBOCHARGED
};

#endif