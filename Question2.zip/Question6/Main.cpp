#include "Operation.h"
#include <future>
int main(){
    std::vector<Car*> vt;
    std::vector<Engine>v;
    std::shared_ptr<Operation> ptr;
    ptr=Operation::getInstance();
    ptr->createObjects(vt,v);

    std::future<std::vector<std::reference_wrapper<Engine>>> r1=std::async(&Operation::getEngineRefrences,*ptr.get(),std::ref(vt));
    r1.get();

        
    
    return 0;

}