#include "Operation.h"
#include "Engine.h"

std::shared_ptr<Operation> Operation::_solo_object = nullptr;

void Operation::createObjects(std::vector<Car *> &Cardata, std::vector<Engine> &EngineData)
{
    EngineData.push_back(Engine("addd", 90, 70, EngineType::CRDI));
    Cardata.push_back(new Car("abc", 990.0f, EngineData[0]));

    EngineData.push_back(Engine("xyz", 100, 80, EngineType::NPFI));
    Cardata.push_back(new Car("def", 1100.0f, EngineData[1]));

    EngineData.push_back(Engine("lmn", 85, 60, EngineType::TURBOCHARGED));
    Cardata.push_back(new Car("ghi", 800.0f, EngineData[2]));

    EngineData.push_back(Engine("pqr", 95, 75, EngineType::CRDI));
    Cardata.push_back(new Car("jkl", 1200.0f, EngineData[3]));

    EngineData.push_back(Engine("uvw", 105, 85, EngineType::TURBOCHARGED));
    Cardata.push_back(new Car("mno", 1300.0f, EngineData[4]));
}

std::vector<std::reference_wrapper<Engine>> Operation::getEngineRefrences(std::vector<Car *> &Cardata)
{
   if(Cardata.size()==0){
    throw std::runtime_error("ERROR");
   }

   std::vector<std::reference_wrapper<Engine>>result;

   result=std::accumulate(
    Cardata.begin(),
    Cardata.end(),
    std::vector<std::reference_wrapper<Engine>>{},
    [&](std::vector<std::reference_wrapper<Engine>> start, Car *ptr){
      start.push_back(ptr->mCarEngine());
      return start;
    }
   );

   return result;
}

bool Operation::allInstanceTorqueAbove120(std::vector<Car *> &Cardata)
{
   if(Cardata.size()==0){
    throw std::runtime_error("ERROR");
   } 

   bool b=std::all_of(
    Cardata.begin(),
    Cardata.end(),
    [](Car *ptr){
        return ptr->mCarEngine().get().mEngineTorque()>60;
    }
   );

   return b;
}

float Operation::findAvgHorspePowerAboveThreshold(std::vector<Car *> &Cardata, int threshold)
{
    if(Cardata.size()==0){
        throw std::runtime_error("ERROR");
    }
    int count =0;

    int sum=std::accumulate(
        Cardata.begin(),
        Cardata.end(),
        0,
        [&](int start, Car *ptr){
            if(ptr->mCarEngine().get().mHorsepower()>threshold){
             start=start+ptr->mCarEngine().get().mHorsepower()>threshold;
             count++;
            }
               
            return start;
        }
    ); 

    return static_cast<float>(sum)/static_cast<float>(count);
    
}

EngineType Operation::findEngineType(std::vector<Car *> &Cardata, std::string _engine_reg_num)
{
    if(Cardata.size()==0){
        throw std::runtime_error("ERROR");
    }

    auto itr=std::find_if(
        Cardata.begin(),
        Cardata.end(),
        [&](Car *ptr){
            return ptr->mCarEngine().get().mEngineNumber()==_engine_reg_num;
        }
    );

    if(itr==Cardata.end()){
        throw std::runtime_error("Not Found");
        
    }
    return (*itr)->mCarEngine().get().mEngineType();
}

std::reference_wrapper<Engine> Operation::findHighestEngine(std::vector<Car*>& Cardata)
{
    if (Cardata.size() == 0) {
        throw std::runtime_error("ERROR");
    }

    auto itr = std::max_element(
        Cardata.begin(),
        Cardata.end(),
        [](Car* ptr1, Car* ptr2) {
            return (ptr1->mCarEngine().get().mEngineTorque()) < (ptr2->mCarEngine().get().mEngineTorque());
        }
    );

    return (*itr)->mCarEngine();
}


std::shared_ptr<Operation> Operation::getInstance()
{
    if (_solo_object != nullptr)
    {
        return _solo_object;
    }
    else
    {
        _solo_object.reset(new Operation());
        return _solo_object;
    }
}
