#ifndef OPERATION_H
#define OPERATION_H

#include<memory>
#include "Car.h"
#include<vector>
#include <numeric>
#include <algorithm>

class Operation
{
private:
    
    static std::shared_ptr<Operation> _solo_object;
    Operation()=default;
public:
      
      ~Operation() = default;

      void createObjects(std::vector<Car*> &Cardata,std::vector<Engine> &EngineData);
      std::vector<std::reference_wrapper<Engine>> getEngineRefrences(std::vector<Car*> &Cardata);
      bool allInstanceTorqueAbove120(std::vector<Car*> &Cardata);

      float findAvgHorspePowerAboveThreshold(std::vector<Car*> &Cardata,int threshold);

      EngineType findEngineType(std::vector<Car*> &Cardata,std::string _engine_reg_num);
      std::reference_wrapper<Engine> findHighestEngine(std::vector<Car*>&data);
  
      Operation(const Operation &) = default;
      Operation &operator=(const Operation &) = default;
  
      Operation(Operation &&other) = default;
      Operation &operator=(Operation &&other) = default;

      static std::shared_ptr<Operation> getInstance();
};

#endif // OPERATION_H
